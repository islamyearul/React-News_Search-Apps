import React, { Component } from 'react';

class Footer extends Component {
    render() {
        return (
            <div>
                <div className='row bg-dark text-white p-3'>
                    <div className='col-md-12'>
                        <div className='d-flex justify-content-center pt-2'>
                            <p>&copy; All Right Reserved | Develop by Islam Yearul </p>
                        </div>
                    </div>
                </div>
            </div>

        );
    }
}

export default Footer;